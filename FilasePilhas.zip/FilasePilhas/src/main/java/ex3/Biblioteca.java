/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex3;

import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author kaike
 */
public class Biblioteca {
    private Stack<pilhaLivro> pilhaLivros = new Stack<>();

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        biblioteca.menu();
    }

    public void menu() {
        String[] options = {"Adicionar Livro", "Listar Livros", "Retirar Livro", "Sair"};
        int opcao;

        do {
            opcao = JOptionPane.showOptionDialog(
                    null,
                    "Escolha uma opção:",
                    "Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            switch (opcao) {
                case 0:
                    adicionarLivro();
                    break;
                case 1:
                    listarLivros();
                    break;
                case 2:
                    retirarLivro();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Encerrando sistema.");
                    break;
                default:
                    break;
            }
        } while (opcao != 3);
    }

    private void adicionarLivro() {
        String titulo = JOptionPane.showInputDialog("Informe o título do livro:");
        String autor = JOptionPane.showInputDialog("Informe o autor do livro:");
        if (titulo != null && !titulo.trim().isEmpty() && autor != null && !autor.trim().isEmpty()) {
            pilhaLivro livro = new pilhaLivro(titulo, autor);
            pilhaLivros.push(livro);
            JOptionPane.showMessageDialog(null, "Livro \"" + titulo + "\" adicionado à pilha.");
        } else {
            JOptionPane.showMessageDialog(null, "Dados inválidos. Tente novamente.");
        }
    }

    private void listarLivros() {
        if (pilhaLivros.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum livro na pilha.");
        } else {
            StringBuilder lista = new StringBuilder("Livros na pilha:\n");
            for (pilhaLivro livro : pilhaLivros) {
                lista.append(livro.toString()).append("\n");
            }
            JOptionPane.showMessageDialog(null, lista.toString());
        }
    }

    private void retirarLivro() {
        if (pilhaLivros.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum livro para retirar.");
        } else {
            pilhaLivro livro = pilhaLivros.pop();
            JOptionPane.showMessageDialog(null, "Livro removido: " + livro.getTitulo());
        }
    }
}
