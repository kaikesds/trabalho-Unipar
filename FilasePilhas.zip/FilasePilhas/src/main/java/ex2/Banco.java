/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex2;

import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;
/**
 *
 * @author kaike
 */
public class Banco {
private static final int LIMITE_SENHAS = 100;
    private Queue<cliente> filaPrioritaria = new LinkedList<>();
    private Queue<cliente> filaNormal = new LinkedList<>();
    private int senhasDistribuidas = 0;
    private int atendimentosPrioritarios = 0;
    
    public static void main(String[] args) {
        Banco banco = new Banco();
            banco.menu();
        
    }

    public void menu() {
        String[] option = {"Adicionar cliente", "Chamar cliente", "Sair"};
        int opcao;
        
        
        do {
            opcao = JOptionPane.showOptionDialog(
                    null,
                    "Escolha uma opção:",
                    "Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    option,
                    option[0]
            );
        
                   
                   
            switch (opcao) {
                case 0:
                    adicionarCliente();
                    break;
                case 1:
                    chamarCliente();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Encerrando sistema.");
                    break;
                default:
                    break;
            }
                    
        } while (opcao != 2);
        
    }
    private void adicionarCliente() {
        if (senhasDistribuidas >= LIMITE_SENHAS) {
            JOptionPane.showMessageDialog(null, "Limite de senhas atingido.");
            return;
        }

        String nome = JOptionPane.showInputDialog("Informe o nome do cliente:");
        String anoStr = JOptionPane.showInputDialog("Informe o ano de nascimento do cliente:");
        if (nome == null || nome.trim().isEmpty() || anoStr == null || anoStr.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Dados inválidos. Tente novamente.");
            return;
        }

        try {
            int anoNascimento = Integer.parseInt(anoStr.trim());
            cliente cliente = new cliente(++senhasDistribuidas, nome, anoNascimento);
            if (2024 - anoNascimento >= 65) { 
                filaPrioritaria.add(cliente);
            } else {
                filaNormal.add(cliente);
            }
            JOptionPane.showMessageDialog(null, "Cliente " + nome + " adicionado à fila");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ano de nascimento inválido. Tente novamente");
        }
    }

    private void chamarCliente() {
        if (atendimentosPrioritarios < 2 && !filaPrioritaria.isEmpty()) {
            cliente cliente = filaPrioritaria.poll();
            JOptionPane.showMessageDialog(null, "Chamando cliente prioritário: " + cliente.getNome());
            atendimentosPrioritarios++;
        } else if (!filaNormal.isEmpty()) {
            cliente cliente = filaNormal.poll();
            JOptionPane.showMessageDialog(null, "Chamando cliente normal: " + cliente.getNome());
            atendimentosPrioritarios = 0; // Reset após atender um cliente normal
        } else if (!filaPrioritaria.isEmpty()) {
            cliente cliente = filaPrioritaria.poll();
            JOptionPane.showMessageDialog(null, "Chamando cliente prioritário: " + cliente.getNome());
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum cliente na fila");
        }
    }


    
    
}
