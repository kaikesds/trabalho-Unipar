/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex4;



import java.awt.HeadlessException;
import java.util.Stack;
import javax.swing.JOptionPane;

public class Deposito {
    private Stack<Produto> pilhaProdutos = new Stack<>();
    private static final int LIMITE_PILHA = 10;

    public static void main(String[] args) {
        Deposito deposito = new Deposito();
        deposito.menu();
    }

    public void menu() {
        String[] options = {"Adicionar Produto", "Retirar Produto", "Exibir Produtos", "Sair"};
        int opcao;

        do {
            opcao = JOptionPane.showOptionDialog(
                    null,
                    "Escolha uma opção:",
                    "Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (opcao == JOptionPane.CLOSED_OPTION) {
                opcao = 3; 
            }

            switch (opcao) {
                case 0:
                    adicionarProduto();
                    break;
                case 1:
                    retirarProduto();
                    break;
                case 2:
                    exibirProdutos();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Encerrando sistema");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida. Tente novamente");
                    break;
            }
        } while (opcao != 3);
    }

    private void adicionarProduto() {
        if (pilhaProdutos.size() >= LIMITE_PILHA) {
            JOptionPane.showMessageDialog(null, "Limite de produtos na pilha atingido");
            return;
        }

        try {
            int codProduto = Integer.parseInt(JOptionPane.showInputDialog("Informe o código do produto:"));
            String descricao = JOptionPane.showInputDialog("Informe a descrição do produto:");
            String dataEntrada = JOptionPane.showInputDialog("Informe a data de entrada (dd/mm/yyyy):");
            String ufOrigem = JOptionPane.showInputDialog("Informe a UF de origem:");
            String ufDestino = JOptionPane.showInputDialog("Informe a UF de destino:");
            Produto produto = new Produto(codProduto, descricao, dataEntrada, ufOrigem, ufDestino);
            pilhaProdutos.push(produto);
            JOptionPane.showMessageDialog(null, "Produto adicionado à pilha");
            exibirProdutos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Código do produto deve ser um número. Tente novamente.");
        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Erro ao adicionar produto. Tente novamente.");
        }
    }

    private void retirarProduto() {
        if (pilhaProdutos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum produto na pilha para retirar.");
        } else {
            Produto produto = pilhaProdutos.pop();
            JOptionPane.showMessageDialog(null, "Produto removido: " + produto);
            exibirProdutos();
        }
    }

    private void exibirProdutos() {
        if (pilhaProdutos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum produto na pilha.");
        } else {
            StringBuilder lista = new StringBuilder("Produtos na pilha:\n");
            for (Produto produto : pilhaProdutos) {
                lista.append(produto).append("\n");
            }
            JOptionPane.showMessageDialog(null, lista.toString());
        }
    }
}


