/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex5;

import ex2.cliente;
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;

/**
 *
 * @author kaike
 */
public class Deposito {
    private static final int NUMERO_PILHAS = 5;
    private static final int LIMITE_CAIXAS_PILHA = 10;

    private Queue<cliente>[] pilhas;

    @SuppressWarnings("unchecked")
    public Deposito() {
        pilhas = new Queue[NUMERO_PILHAS];
        for (int i = 0; i < NUMERO_PILHAS; i++) {
            pilhas[i] = new LinkedList<>();
        }
    }

    public static void main(String[] args) {
        Deposito deposito = new Deposito();
        deposito.menu();
    }

    public void menu() {
        String[] options = {"Adicionar Caixa", "Retirar Caixa", "Exibir Pilhas", "Sair"};
        int opcao;

        do {
            opcao = JOptionPane.showOptionDialog(
                    null,
                    "Escolha uma opção:",
                    "Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (opcao == JOptionPane.CLOSED_OPTION) {
                opcao = 3; 
            }

            switch (opcao) {
                case 0:
                    adicionarCaixa();
                    break;
                case 1:
                    retirarCaixa();
                    break;
                case 2:
                    exibirPilhas();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Encerrando sistema.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida. Tente novamente.");
                    break;
            }

        } while (opcao != 3);
    }

    private void adicionarCaixa() {
        int pilhaSelecionada = selecionarPilha();
        if (pilhaSelecionada == -1) {
            JOptionPane.showMessageDialog(null, "Operação cancelada.");
            return;
        }

        if (pilhas[pilhaSelecionada].size() >= LIMITE_CAIXAS_PILHA) {
            JOptionPane.showMessageDialog(null, "Limite de caixas na pilha atingido (máximo 10 caixas).");
            return;
        }

        try {
            int senha = Integer.parseInt(JOptionPane.showInputDialog("Informe o número da senha do cliente:"));
            String nome = JOptionPane.showInputDialog("Informe o nome do cliente:");
            int anoNascimento = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano de nascimento do cliente:"));

            cliente cliente = new cliente(senha, nome, anoNascimento);
            pilhas[pilhaSelecionada].add(cliente);

            JOptionPane.showMessageDialog(null, "Caixa adicionada à pilha " + pilhaSelecionada + ".");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Tente novamente.");
        }
    }

    private void retirarCaixa() {
        int pilhaSelecionada = selecionarPilha();
        if (pilhaSelecionada == -1) {
            JOptionPane.showMessageDialog(null, "Operação cancelada.");
            return;
        }

        if (pilhas[pilhaSelecionada].isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhuma caixa na pilha " + pilhaSelecionada + ".");
            return;
        }

        cliente cliente = pilhas[pilhaSelecionada].poll();
        JOptionPane.showMessageDialog(null, "Caixa retirada da pilha " + pilhaSelecionada + ": " + cliente);
    }

    private void exibirPilhas() {
        StringBuilder mensagem = new StringBuilder("Estado das pilhas:\n");
        for (int i = 0; i < NUMERO_PILHAS; i++) {
            mensagem.append("Pilha ").append(i).append(": ");
            if (pilhas[i].isEmpty()) {
                mensagem.append("Vazia\n");
            } else {
                mensagem.append(pilhas[i].size()).append(" caixa(s)\n");
            }
        }
        JOptionPane.showMessageDialog(null, mensagem.toString());
    }

    private int selecionarPilha() {
        String[] opcoesPilhas = new String[NUMERO_PILHAS + 1];
        opcoesPilhas[0] = "Cancelar";
        for (int i = 0; i < NUMERO_PILHAS; i++) {
            opcoesPilhas[i + 1] = "Pilha " + i;
        }

        int opcaoPilha = JOptionPane.showOptionDialog(
                null,
                "Selecione a pilha:",
                "Selecionar Pilha",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoesPilhas,
                opcoesPilhas[0]
        );

        return opcaoPilha - 1;
    }
}
