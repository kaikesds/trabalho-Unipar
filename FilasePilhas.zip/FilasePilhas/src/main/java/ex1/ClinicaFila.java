/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex1;

import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;

/**
 *
 * @author kaike
 */
public class ClinicaFila {
    private static final int LIMITE_SENHAS = 15;
    private Queue<String> filaPacientes = new LinkedList<>();
    private int senhasDistribuidas = 0;

    public static void main(String[] args) {
        ClinicaFila clinicaFila = new ClinicaFila();
        clinicaFila.menu();
    }

    public void menu() {
        String[] options = {"Adicionar paciente", "Chamar proximo paciente", "Sair"};
        int opcao;

        do {
            opcao = JOptionPane.showOptionDialog( null, "Escolha uma opção:", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
            null, options, options[0]);

            switch (opcao) {
                case 0:
                    adicionarPaciente();
                    break;
                case 1:
                    chamarProximoPaciente();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "sistema foi encerrado.");
                    break;
                default:
                    break;
            }
        } while (opcao != 2);
    }

    private void adicionarPaciente() {
        if (senhasDistribuidas >= LIMITE_SENHAS) {
            JOptionPane.showMessageDialog(null, "Limite de senhas atingido.");
            return;
        }

        String nomePaciente = JOptionPane.showInputDialog("Informe o nome do paciente:");
        if (nomePaciente != null && !nomePaciente.trim().isEmpty()) {
            filaPacientes.add(nomePaciente);
            senhasDistribuidas++;
            JOptionPane.showMessageDialog(null, "Paciente " + nomePaciente + " adicionado a fila.");
        } else {
            JOptionPane.showMessageDialog(null, "Nome inválido Tente novamente.");
        }
    }

    private void chamarProximoPaciente() {
        if (filaPacientes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum paciente na fila.");
        } else {
            String proximoPaciente = filaPacientes.poll();
            JOptionPane.showMessageDialog(null, "Próximo paciente: " + proximoPaciente);
        }
    }

}
