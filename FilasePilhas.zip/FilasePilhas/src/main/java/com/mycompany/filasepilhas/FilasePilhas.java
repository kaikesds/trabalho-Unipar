/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.filasepilhas;

/**
 *
 * @author kaike
 */
public class FilasePilhas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
